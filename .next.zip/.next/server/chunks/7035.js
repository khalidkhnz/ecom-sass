"use strict";exports.id=7035,exports.ids=[7035],exports.modules={28917:(e,r,t)=>{t.d(r,{$u:()=>d,PT:()=>i,fC:()=>o,h5:()=>n,oL:()=>a});var s=t(68567);let a=s.z.object({id:s.z.string().optional(),name:s.z.string().min(1,"Name is required"),addressLine1:s.z.string().min(1,"Address is required"),addressLine2:s.z.string().optional(),city:s.z.string().min(1,"City is required"),state:s.z.string().min(1,"State is required"),postalCode:s.z.string().min(1,"Postal code is required"),country:s.z.string().min(1,"Country is required"),phone:s.z.string().optional(),isDefault:s.z.boolean()}),d=a,o=s.z.object({addressId:s.z.string(),address:a}),i=s.z.object({addressId:s.z.string()}),n=s.z.object({addressId:s.z.string()})},97035:(e,r,t)=>{t.d(r,{fS:()=>E,Vd:()=>O,p:()=>z,f1:()=>_,W2:()=>R,FK:()=>S,Kv:()=>v,KF:()=>A});var s=t(91199);t(42087);var a=t(83570),d=t(61446),o=t(9352),i=t(42999),n=t(48159),c=t(18839),u=t(70337),l=t(7944),m=t(55511),p=t.n(m),g=t(95115),y=t(68567),f=t(28917);let b=y.z.object({billingAddress:f.oL,shippingAddress:f.oL,useShippingAsBilling:y.z.boolean().optional(),paymentMethod:y.z.enum(["razorpay"]),customerNote:y.z.string().optional()}),h=y.z.object({orderId:y.z.string(),paymentId:y.z.string(),signature:y.z.string()});y.z.object({success:y.z.boolean(),message:y.z.string(),orderId:y.z.string().optional(),orderNumber:y.z.string().optional(),redirectUrl:y.z.string().optional(),paymentData:y.z.record(y.z.any()).optional(),error:y.z.any().optional()});var I=t(33331);let w=new(t(40934))({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});async function $(){let e=await (0,i.j2)();if(!e?.user?.id)throw Error("You must be logged in to place an order");return e.user}async function E(e){try{let r=b.parse(e),t=await $(),s=t.id,i=await (0,n.Xl)();if(!i.items.length)return{success:!1,message:"Your cart is empty"};let u=function(){let e=Date.now().toString(),r=Math.floor(1e4*Math.random()).toString().padStart(4,"0");return`ORD-${e.slice(-8)}-${r}`}(),l=r.useShippingAsBilling?r.shippingAddress:r.billingAddress,m=(0,o.sX)();await a.db.insert(d.orders).values({userId:s,id:m,orderNumber:u,status:"pending",subTotal:i.subtotal.toString(),taxAmount:"0",shippingAmount:"0",discountAmount:"0",grandTotal:i.subtotal.toString(),shippingAddress:r.shippingAddress,billingAddress:l,customerNote:r.customerNote||"",paymentMethod:r.paymentMethod,paymentStatus:"pending"});let[p]=await a.db.select().from(d.orders).where((0,c.eq)(d.orders.id,m));for(let e of i.items){let r={id:e.product.id,name:e.product.name,price:e.product.price,discountPrice:e.product.discountPrice,images:e.product.images,slug:e.product.slug,taxable:e.product.taxable,taxRate:e.product.taxRate,taxType:e.product.taxType,variant:e.variant||null},t=e.variant?.price?parseFloat(String(e.variant.price)):e.product.discountPrice?parseFloat(String(e.product.discountPrice)):parseFloat(String(e.product.price)),s=(0,o.sX)();await a.db.insert(d.orderItems).values({id:s,orderId:p.id,productId:e.product.id,variantId:e.variant?.id||null,sku:"SKU-"+e.product.id,name:e.product.name,price:t.toString(),quantity:e.quantity.toString(),totalPrice:(t*e.quantity).toString(),productData:r})}let g=Math.round(100*parseFloat(p.grandTotal)),y=await w.orders.create({amount:g,currency:"INR",receipt:p.orderNumber,notes:{orderId:p.id,userId:s}}),f={razorpayOrderId:y.id};return await a.db.update(d.orders).set({paymentDetails:f}).where((0,c.eq)(d.orders.id,p.id)),{success:!0,message:"Order created successfully",orderId:p.id,orderNumber:p.orderNumber,paymentData:{orderId:y.id,amount:y.amount,currency:y.currency,key:process.env.RAZORPAY_KEY_ID,name:"E-Commerce Store",description:`Payment for order ${p.orderNumber}`,prefill:{name:t.name||"",email:t.email||"",contact:l.phone||""},notes:{address:`${l.addressLine1}, ${l.city}, ${l.state}, ${l.country}`}}}}catch(e){return console.error("Error creating order:",e),{success:!1,message:e.message||"Failed to create order",error:e}}}async function A(e){try{let r=h.parse(e),t=await a.db.execute((0,g.ll)`
      SELECT * FROM "orders" 
      WHERE payment_details->>'razorpayOrderId' = ${r.orderId}
      LIMIT 1
    `);if(!t.rows||0===t.rows.length)return{success:!1,message:"Order not found"};let s=t.rows[0];if(p().createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(`${r.orderId}|${r.paymentId}`).digest("hex")!==r.signature)return await a.db.execute((0,g.ll)`
        UPDATE "orders"
        SET 
          "payment_status" = 'failed',
          "status" = 'payment_failed'
        WHERE "id" = ${s.id}
      `),{success:!1,message:"Payment verification failed"};let d=await w.payments.fetch(r.paymentId),i=(0,o.sX)();await a.db.execute((0,g.ll)`
      INSERT INTO "payments" (
        "id", 
        "order_id", 
        "razorpay_order_id", 
        "razorpay_payment_id", 
        "razorpay_signature", 
        "amount", 
        "currency", 
        "method", 
        "status", 
        "payment_data",
        "created_at",
        "updated_at"
      ) VALUES (
        ${i},
        ${s.id},
        ${r.orderId},
        ${r.paymentId},
        ${r.signature},
        ${s.grand_total},
        'INR',
        'razorpay',
        ${d.status},
        ${JSON.stringify(d)},
        now(),
        now()
      )
    `);let c=JSON.stringify({razorpayOrderId:r.orderId,paymentId:r.paymentId,signature:r.signature,paymentStatus:"completed"});return await a.db.execute((0,g.ll)`
      UPDATE "orders"
      SET 
        "payment_status" = 'completed',
        "status" = 'processing',
        "payment_details" = ${c}::jsonb
      WHERE "id" = ${s.id}
    `),await (0,n.sX)(),(0,l.revalidatePath)("/checkout/success"),(0,l.revalidatePath)("/user/orders"),{success:!0,message:"Payment verified successfully",orderId:s.id,orderNumber:s.order_number,redirectUrl:`/checkout/success?orderId=${s.id}`}}catch(e){return console.error("Error verifying payment:",e),{success:!1,message:e.message||"Failed to verify payment",error:e}}}async function z(e){try{let r=await $(),t=await a.db.query.orders.findFirst({where:(0,c.Uo)((0,c.eq)(d.orders.id,e),(0,c.eq)(d.orders.userId,r.id)),with:{items:!0}});if(!t)return{success:!1,message:"Order not found"};return{success:!0,order:t}}catch(e){return console.error("Error getting order:",e),{success:!1,message:e.message||"Failed to get order",error:e}}}async function S(){try{let e=await $(),r=await a.db.query.orders.findMany({where:(0,c.eq)(d.orders.userId,e.id),orderBy:(e,{desc:r})=>[r(e.createdAt)]});return{success:!0,orders:r}}catch(e){return console.error("Error getting user orders:",e),{success:!1,message:e.message||"Failed to get orders",error:e}}}async function R(e){try{let r=await $(),t=await a.db.query.orders.findFirst({where:(0,c.Uo)((0,c.eq)(d.orders.id,e),(0,c.eq)(d.orders.userId,r.id),(0,c.eq)(d.orders.paymentStatus,"pending"))});if(!t)return{success:!1,message:"Order not found or payment is not pending"};if(!t.paymentDetails?.razorpayOrderId)return{success:!1,message:"Payment information not found for this order"};let s=await a.db.query.users.findFirst({where:(0,c.eq)(d.users.id,r.id),columns:{name:!0,email:!0}});return{success:!0,orderId:t.id,orderNumber:t.orderNumber,paymentData:{orderId:t.paymentDetails.razorpayOrderId,amount:100*parseFloat(t.grandTotal),currency:"INR",key:process.env.RAZORPAY_KEY_ID,name:"E-Commerce Store",description:`Payment for order ${t.orderNumber}`,prefill:{name:s?.name||"",email:s?.email||"",contact:t.billingAddress?.phone||""},notes:{address:`${t.billingAddress?.addressLine1}, ${t.billingAddress?.city}, ${t.billingAddress?.state}, ${t.billingAddress?.country}`}}}}catch(e){return console.error("Error getting pending payment data:",e),{success:!1,message:e.message||"Failed to get payment information",error:e}}}async function q(){let e=await (0,i.j2)();if(!e?.user?.id)throw Error("You must be logged in to access this resource");if("admin"!==e.user.role)throw Error("You don't have permission to access this resource");return e.user}async function O(e=1,r=10,t){try{await q();let s=a.db.select().from(d.orders);if(t&&(t.status&&"all"!==t.status&&(s=s.where((0,c.eq)(d.orders.status,t.status))),t.paymentStatus&&"all"!==t.paymentStatus&&(s=s.where((0,c.eq)(d.orders.paymentStatus,t.paymentStatus))),t.search&&(s=s.where((0,g.ll)`${d.orders.orderNumber} ILIKE ${"%"+t.search+"%"} OR 
              ${d.orders.userId} ILIKE ${"%"+t.search+"%"} OR
              EXISTS (
                SELECT 1 FROM ${d.users}
                WHERE ${d.users.id} = ${d.orders.userId}
                AND (
                  ${d.users.name} ILIKE ${"%"+t.search+"%"} OR
                  ${d.users.email} ILIKE ${"%"+t.search+"%"}
                )
              ) OR
              ${d.orders.billingAddress}->>'name' ILIKE ${"%"+t.search+"%"} OR
              ${d.orders.billingAddress}->>'addressLine1' ILIKE ${"%"+t.search+"%"} OR
              ${d.orders.billingAddress}->>'city' ILIKE ${"%"+t.search+"%"} OR
              ${d.orders.billingAddress}->>'postalCode' ILIKE ${"%"+t.search+"%"} OR
              ${d.orders.billingAddress}->>'phone' ILIKE ${"%"+t.search+"%"} OR
              ${d.orders.shippingAddress}->>'phone' ILIKE ${"%"+t.search+"%"}`)),t.fromDate&&(s=s.where((0,g.ll)`${d.orders.createdAt} >= ${new Date(t.fromDate)}`)),t.toDate)){let e=new Date(t.toDate);e.setHours(23,59,59,999),s=s.where((0,g.ll)`${d.orders.createdAt} <= ${e}`)}let o=await a.db.select({count:(0,g.ll)`count(*)`}).from(d.orders),i=Number(o[0].count),n=await s.orderBy((0,u.i)(d.orders.createdAt)).limit(r).offset((e-1)*r);return{success:!0,orders:n,pagination:{total:i,page:e,limit:r,totalPages:Math.ceil(i/r)}}}catch(e){return console.error("Error getting all orders:",e),{success:!1,message:e.message||"Failed to get orders",error:e}}}async function _(e){try{await q();let r=await a.db.query.orders.findFirst({where:(0,c.eq)(d.orders.id,e),with:{items:!0}});if(!r)return{success:!1,message:"Order not found"};let t=await a.db.query.users.findFirst({where:(0,c.eq)(d.users.id,r.userId),columns:{id:!0,name:!0,email:!0}});return{success:!0,order:{...r,user:t}}}catch(e){return console.error("Error getting order details:",e),{success:!1,message:e.message||"Failed to get order details",error:e}}}async function v(e,r){try{if(await q(),!await a.db.query.orders.findFirst({where:(0,c.eq)(d.orders.id,e)}))return{success:!1,message:"Order not found"};return await a.db.update(d.orders).set({status:r,updatedAt:new Date}).where((0,c.eq)(d.orders.id,e)),("delivered"===r||"completed"===r)&&await a.db.update(d.orders).set({paymentStatus:"completed"}).where((0,c.eq)(d.orders.id,e)),{success:!0,message:"Order status updated successfully"}}catch(e){return console.error("Error updating order status:",e),{success:!1,message:e.message||"Failed to update order status",error:e}}}(0,I.D)([E,A,z,S,R,O,_,v]),(0,s.A)(E,"40bd6d9b320f43f897a481fb8912a4f1c4e394c330",null),(0,s.A)(A,"40634079e81ae10285ee55fe6ed10c5ac35bc78c66",null),(0,s.A)(z,"40daaeb85dfb284942cc1220d8a46fc3f7a95ff09d",null),(0,s.A)(S,"00f3ed9b932c6922bb0eab069fad76d3c24e26abad",null),(0,s.A)(R,"4044504b756814643dc1e0cacb72a82961c0eadb14",null),(0,s.A)(O,"70e7f675ce67366012cdd9131ec483da8a316487b8",null),(0,s.A)(_,"4086ac80453fdaa56d39646f5b612e0a9e8bbded59",null),(0,s.A)(v,"605869a61c04a0f48bf939d8b3af7320e1e6b3fadf",null)}};